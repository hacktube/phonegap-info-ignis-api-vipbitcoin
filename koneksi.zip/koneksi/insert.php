<?php 
header("Access-Control-Allow-Origin: *");

/*$date = $_GET['date'];
$time = $_GET['time'];*/
$last = $_POST['last'];
$buy = $_POST['buy'];
$sell  = $_POST['sell'];
$high = $_POST['high'];
$low = $_POST['low'];
$volbtc = $_POST['volbtc'];
$volidr = $_POST['volidr'];

include 'koneksi.php';

$sql = "insert into api_btc (last_btc,buy_btc,sell_btc,high_btc,low_btc,vol_btc,vol_idr) values ('$last','$buy','$sell','$high','$low','$volbtc','$volidr')";
$result = mysqli_query($koneksi, $sql) 
    or die("Error in Selecting " . mysqli_error($koneksi));
mysqli_close($koneksi);
?>