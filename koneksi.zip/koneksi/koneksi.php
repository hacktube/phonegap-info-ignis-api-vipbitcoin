<?php
$koneksi = mysqli_connect("localhost","root","","test") 
    or die("Error ".mysqli_error($koneksi));

  ?>