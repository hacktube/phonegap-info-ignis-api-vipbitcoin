<?php 
header("Access-Control-Allow-Origin: *");

include "koneksi.php";
//Mengambil data pada table dari database MySQL
$sql = "select * from notif order by ID desc";
$result = mysqli_query($koneksi, $sql) 
    or die("Error in Selecting " . mysqli_error($koneksi));
//Membuat array
$identitas = array();
while($row =mysqli_fetch_assoc($result))
{
  $identitas[] = $row;
}
//Menampilkan konversi data pada tabel identitas ke format JSON
echo json_encode($identitas);
//close the db connection
mysqli_close($koneksi);
?>